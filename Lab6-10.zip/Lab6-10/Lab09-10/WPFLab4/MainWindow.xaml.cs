﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace WPFLab4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Student> ListaStudentow { get; set; }


        public MainWindow()
        {
            ListaStudentow = new List<Student>()
            {
                new Student("Jan", "Kowalski", 1234, "KIS", new List<Ocena>(){new Ocena(5), new Ocena(4)}),
                new Student("Anna", "Nowak", 4321, "KIS", new List<Ocena>(){new Ocena(3), new Ocena(4)}),
                new Student("Michał", "Jacek", 1357, "KIS", new List<Ocena>(){new Ocena(3), new Ocena(5)}),
            };

            InitializeComponent();

            Tabela.Columns.Add(new DataGridTextColumn() { Header="Imię", Binding = new Binding("Imie")});
            Tabela.Columns.Add(new DataGridTextColumn() { Header = "Nazwisko", Binding = new Binding("Nazwisko") });
            Tabela.Columns.Add(new DataGridTextColumn() { Header = "Nr indeksu", Binding = new Binding("NRIndeksu") });
            Tabela.Columns.Add(new DataGridTextColumn() { Header = "Wydział", Binding = new Binding("Wydzial") });

            Tabela.AutoGenerateColumns = false;
            Tabela.ItemsSource = ListaStudentow;

        }


        private void DodajBttn_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new StudentEdit();
            if (dialog.ShowDialog() == true)
            {
                ListaStudentow.Add(dialog.student);
                Tabela.Items.Refresh();
            }
        }

        private void UsunBttn_Click(object sender, RoutedEventArgs e)
        {
            if (Tabela.SelectedItem is Student)
                ListaStudentow.Remove((Student)Tabela.SelectedItem);
            Tabela.Items.Refresh();
        }

        private void WyswietlOcenyBttn_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OcenyInfo((Student)Tabela.SelectedItem);
            dialog.Show();
        }

        private void DodajOceneBttn_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new DodajOcene((Student)Tabela.SelectedItem);
            dialog.Show();
        }

        private void LoadBttn_Click(object sender, RoutedEventArgs e)
        {
            try { 
            var Sciezka = "";
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (openFileDialog.ShowDialog() == true)
            {
                Sciezka = openFileDialog.FileName;
            }



            List<Student> nowaListaStudentow = new List<Student>();

            var plik = File.ReadAllLines(Sciezka);
            List<String> listaLinii = new List<string>(plik);



            for(int i=0; i<listaLinii.Count; i+=10)
            {
                String im = listaLinii[i + 2];
                String naz = listaLinii[i + 4];
                String nr = listaLinii[i + 6];
                String wyd = listaLinii[i + 8];

                Student stud = new Student(im, naz, int.Parse(nr), wyd, new List<Ocena>());

                nowaListaStudentow.Add(stud);
            }

            ListaStudentow.Clear();

            for(int a =0; a<nowaListaStudentow.Count; a++)
            {
                ListaStudentow.Add(nowaListaStudentow[a]);
            }

            Tabela.Items.Refresh();
            MessageBox.Show("Wczytano");
            }
            catch (Exception)
            {
                MessageBox.Show("Wystąpił błąd");
            }

        }

        private void SaveBttn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var Sciezka = "";
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                if (openFileDialog.ShowDialog() == true)
                {
                    Sciezka = openFileDialog.FileName;
                }

                FileStream fs = new FileStream(Sciezka, FileMode.Create);
                StreamWriter sw = new StreamWriter(fs);
                for (int i = 0; i < ListaStudentow.Count; i++)
                {
                    sw.WriteLine("[[Student]]");
                    sw.WriteLine("[Imie]");
                    sw.WriteLine(ListaStudentow[i].Imie);
                    sw.WriteLine("[Nazwisko]");
                    sw.WriteLine(ListaStudentow[i].Nazwisko);
                    sw.WriteLine("[NRIndeksu]");
                    sw.WriteLine(ListaStudentow[i].NRIndeksu);
                    sw.WriteLine("[Wydzial]");
                    sw.WriteLine(ListaStudentow[i].Wydzial);
                    sw.WriteLine("[[]]");
                }

                sw.Close();
                MessageBox.Show("Zapisano");

            }
            catch (Exception)
            {
                MessageBox.Show("Wystąpił błąd");
            }
            
        }

        private void SaveDyn_Click(object sender, RoutedEventArgs e)
        {
            try { 
            var Sciezka = "";
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (openFileDialog.ShowDialog() == true)
            {
                Sciezka = openFileDialog.FileName;
            }
            FileStream fs = new FileStream(Sciezka, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            for (int a = 0; a < ListaStudentow.Count; a++)
            {
                Save(ListaStudentow[a], sw);
            }
            
            sw.Close();
                MessageBox.Show("Zapisano");
            }
            catch (Exception)
            {
                MessageBox.Show("Wystąpił błąd");
            }


        }

        private void LoadDyn_Click(object sender, RoutedEventArgs e)
        {
            try { 
            var Sciezka = "";
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (openFileDialog.ShowDialog() == true)
            {
                Sciezka = openFileDialog.FileName;
            }
            FileStream fs = new FileStream("zapisLista.txt", FileMode.Create);
            StreamReader sr = new StreamReader(fs);
            for (int a = 0; a < ListaStudentow.Count; a++)
                Tabela.ItemsSource=Load<List<Student>>(sr);

            Tabela.Items.Refresh();

            sr.Close();
                MessageBox.Show("Wczytano");
            }
            catch (Exception)
            {
                MessageBox.Show("Wystąpił błąd");
            }
        }

        private void SaveXML_Click(object sender, RoutedEventArgs e)
        {
            try { 
            var Sciezka = "";
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (openFileDialog.ShowDialog() == true)
            {
                Sciezka = openFileDialog.FileName;
            }

            List<Student> nowaListaStudentow = new List<Student>();
            FileStream fs = new FileStream(Sciezka, FileMode.Create);
            XmlSerializer serializer = new XmlSerializer(typeof(List<Student>));

            serializer.Serialize(fs, nowaListaStudentow);

            fs.Close();
                MessageBox.Show("Zapisano");
            }
            catch (Exception)
            {
                MessageBox.Show("Wystąpił błąd");
            }
        }

        private void LoadXML_Click(object sender, RoutedEventArgs e)
        {
            try { 
            var Sciezka = "";
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            if (openFileDialog.ShowDialog() == true)
            {
                Sciezka = openFileDialog.FileName;
            }

            List<Student> nowaListaStudentow = new List<Student>();
            FileStream fs = new FileStream(Sciezka, FileMode.Create);
            XmlSerializer serializer = new XmlSerializer(typeof(List<Student>));

            nowaListaStudentow = (List<Student>)serializer.Deserialize(fs);
            fs.Close();

            ListaStudentow.Clear();

            for (int a = 0; a < nowaListaStudentow.Count; a++)
            {
                ListaStudentow.Add(nowaListaStudentow[a]);
            }

            Tabela.Items.Refresh();

                MessageBox.Show("Wczytano");
            }
            catch (Exception)
            {
                MessageBox.Show("Wystąpił błąd");
            }

        }

        void Save<T>(T ob, StreamWriter sw)
        {
            Type t = ob.GetType();
            sw.WriteLine($"[[{t.FullName}]]");
            foreach(var p  in t.GetProperties())
            {
                sw.WriteLine($"[{p.Name}]");
                sw.WriteLine(p.GetValue(ob));
            }
            sw.WriteLine($"[[]]");

        }

        public T Load<T>(StreamReader sr) where T : new()
        {
            T ob = default(T);
            Type tob = null;
            PropertyInfo property = null;

            while (!sr.EndOfStream)
            {

                var ln = sr.ReadLine();
                if (ln == "[[]]")
                    return ob;
                else if (ln.StartsWith("[["))
                {
                    tob = Type.GetType(ln.Trim('[', ']'));
                    if (typeof(T).IsAssignableFrom(tob))
                        ob = (T)Activator.CreateInstance(tob);
                }
                else if (ln.StartsWith("[") && ob != null)
                    property = tob.GetProperty(ln.Trim('[', ']'));
                else if (ob != null && property != null)
                    property.SetValue(ob, Convert.ChangeType(ln, property.PropertyType));
            }
            return default;
        }
    }
}



