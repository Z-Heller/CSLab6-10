﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFLab4
{
    public class Student
    {
        public String Imie { get; set; }
        public String Nazwisko { get; set; }
        public int NRIndeksu { get; set; }
        public String Wydzial { get; set; }
        public List<Ocena> Oceny { get; set; }


        public Student(string imie, string nazwisko, int nRIndeksu, string wydzial, List<Ocena> oceny)
        {
            Imie = imie;
            Nazwisko = nazwisko;
            NRIndeksu = nRIndeksu;
            Wydzial = wydzial;
            Oceny = oceny;
        }

        public Student(): this("", "", 0, "", new List<Ocena>()) { }
        
    }
}
