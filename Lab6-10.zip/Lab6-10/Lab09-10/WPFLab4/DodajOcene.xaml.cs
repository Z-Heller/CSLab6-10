﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFLab4
{
    /// <summary>
    /// Interaction logic for DodajOcene.xaml
    /// </summary>
    public partial class DodajOcene : Window
    {
        private Student student;
        public DodajOcene(Student student)
        {
            InitializeComponent();
            this.student = student;
        }

        private void DodajBttn_Click(object sender, RoutedEventArgs e)
        {
            string str = SelectOcena.SelectedItem.ToString();
            student.Oceny.Add(new Ocena(int.Parse(str.Substring(str.Length-1))));
            this.Close();
        }
    }
}
