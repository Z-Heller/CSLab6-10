﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFLab4
{
    public class Ocena
    {
        public int ocena;

        public Ocena(int ocena)
        {
            this.ocena = ocena;
        }

        public Ocena()
        {
        }
    }
}
