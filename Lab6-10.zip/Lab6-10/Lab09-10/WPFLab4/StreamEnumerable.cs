﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WPFLab4
{
    class StreamEnumerable<T> : IEnumerable<T>
    {
        public StreamReader sr { get; set; }
        public List<T> IListaStudentow { get; set; }

        public StreamEnumerable(StreamReader sr)
        {
            this.sr = sr;
            try
            {
                var Sciezka = "";
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                if (openFileDialog.ShowDialog() == true)
                {
                    Sciezka = openFileDialog.FileName;
                }



                List<Student> IListaStudentow = new List<Student>();

                var plik = File.ReadAllLines(Sciezka);
                List<String> listaLinii = new List<string>(plik);



                for (int i = 0; i < listaLinii.Count; i += 10)
                {
                    String im = listaLinii[i + 2];
                    String naz = listaLinii[i + 4];
                    String nr = listaLinii[i + 6];
                    String wyd = listaLinii[i + 8];

                    Student stud = new Student(im, naz, int.Parse(nr), wyd, new List<Ocena>());

                    IListaStudentow.Add(stud);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Wystąpił błąd");
            }
        }


        public IEnumerator<T> GetEnumerator()
        {
            return IListaStudentow.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        public T MoveNext()
        {
            T ob = default(T);
            Type tob = null;
            PropertyInfo property = null;

            
                var ln = sr.ReadLine();
                if (ln == "[[]]")
                    return ob;
                else if (ln.StartsWith("[["))
                {
                    tob = Type.GetType(ln.Trim('[', ']'));
                    if (typeof(T).IsAssignableFrom(tob))
                        ob = (T)Activator.CreateInstance(tob);
                }
                else if (ln.StartsWith("[") && ob != null)
                    property = tob.GetProperty(ln.Trim('[', ']'));
                else if (ob != null && property != null)
                    property.SetValue(ob, Convert.ChangeType(ln, property.PropertyType));
            
            return default;
        }
    }
}

