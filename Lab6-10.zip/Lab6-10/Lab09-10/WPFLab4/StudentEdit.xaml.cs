﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFLab4
{
    /// <summary>
    /// Interaction logic for StudentEdit.xaml
    /// </summary>
    public partial class StudentEdit : Window
    {
        public Student student;
        public StudentEdit(Student student = null)
        {
            InitializeComponent();
            if (student != null)
            {
                tbImie.Text = student.Imie;
                tbNazwisko.Text = student.Nazwisko;
                tbNRAlbumu.Text = student.NRIndeksu.ToString();
                tbWydzial.Text = student.Wydzial;

            }

            this.student = student ?? new Student();


        }

        public StudentEdit()
        {
            InitializeComponent();
        }
        private void OKbttn_Click(object sender, RoutedEventArgs e)
        {
            this.student = student ?? new Student();
            if (!Regex.IsMatch(tbImie.Text, @"^\p{Lu}\p{Ll}{1,12}$")  ||
                !Regex.IsMatch(tbNazwisko.Text, @"^\p{Lu}\p{Ll}{1,12}$") ||
                 !Regex.IsMatch(tbNRAlbumu.Text, @"^\p{N}{1,12}$") ||
                 !Regex.IsMatch(tbWydzial.Text, @"^\p{Lu}{1,4}$"))
            {
                MessageBox.Show("Niepoprawne dane");
                return;
            }

            student.Imie = tbImie.Text;
            student.Nazwisko = tbNazwisko.Text;
            student.NRIndeksu = int.Parse(tbNRAlbumu.Text);
            student.Wydzial = tbWydzial.Text;

            this.DialogResult = true;

        }
    }
}
