﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFLab4
{
    /// <summary>
    /// Interaction logic for OcenyInfo.xaml
    /// </summary>
    public partial class OcenyInfo : Window
    {
        public OcenyInfo(Student student)
        {
            InitializeComponent();

            for(int i =0; i<student.Oceny.Count; i++)
            {
                OcenyField.Text += student.Oceny[i].ocena.ToString() + "\n";
            }
        }
    }
}
