﻿
namespace FormTekst
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radBarDuza = new System.Windows.Forms.RadioButton();
            this.radDuza = new System.Windows.Forms.RadioButton();
            this.radMala = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkPodkresl = new System.Windows.Forms.CheckBox();
            this.checkPochylenie = new System.Windows.Forms.CheckBox();
            this.checkPogrubienie = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radPomar = new System.Windows.Forms.RadioButton();
            this.radNiebieski = new System.Windows.Forms.RadioButton();
            this.radCzerwony = new System.Windows.Forms.RadioButton();
            this.AktualizujBtn = new System.Windows.Forms.Button();
            this.textBox = new System.Windows.Forms.RichTextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(44, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "Podaj tekst:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radBarDuza);
            this.groupBox1.Controls.Add(this.radDuza);
            this.groupBox1.Controls.Add(this.radMala);
            this.groupBox1.Location = new System.Drawing.Point(44, 123);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(205, 198);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Wielkość";
            // 
            // radBarDuza
            // 
            this.radBarDuza.AutoSize = true;
            this.radBarDuza.Location = new System.Drawing.Point(6, 155);
            this.radBarDuza.Name = "radBarDuza";
            this.radBarDuza.Size = new System.Drawing.Size(113, 24);
            this.radBarDuza.TabIndex = 2;
            this.radBarDuza.TabStop = true;
            this.radBarDuza.Text = "Bardzo duża";
            this.radBarDuza.UseVisualStyleBackColor = true;
            // 
            // radDuza
            // 
            this.radDuza.AutoSize = true;
            this.radDuza.Location = new System.Drawing.Point(6, 99);
            this.radDuza.Name = "radDuza";
            this.radDuza.Size = new System.Drawing.Size(64, 24);
            this.radDuza.TabIndex = 1;
            this.radDuza.TabStop = true;
            this.radDuza.Text = "Duża";
            this.radDuza.UseVisualStyleBackColor = true;
            // 
            // radMala
            // 
            this.radMala.AutoSize = true;
            this.radMala.Location = new System.Drawing.Point(6, 44);
            this.radMala.Name = "radMala";
            this.radMala.Size = new System.Drawing.Size(63, 24);
            this.radMala.TabIndex = 0;
            this.radMala.TabStop = true;
            this.radMala.Text = "Mała";
            this.radMala.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkPodkresl);
            this.groupBox2.Controls.Add(this.checkPochylenie);
            this.groupBox2.Controls.Add(this.checkPogrubienie);
            this.groupBox2.Location = new System.Drawing.Point(300, 123);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(205, 198);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Styl czcionki";
            // 
            // checkPodkresl
            // 
            this.checkPodkresl.AutoSize = true;
            this.checkPodkresl.Location = new System.Drawing.Point(6, 156);
            this.checkPodkresl.Name = "checkPodkresl";
            this.checkPodkresl.Size = new System.Drawing.Size(114, 24);
            this.checkPodkresl.TabIndex = 2;
            this.checkPodkresl.Text = "Podkreślenie";
            this.checkPodkresl.UseVisualStyleBackColor = true;
            // 
            // checkPochylenie
            // 
            this.checkPochylenie.AutoSize = true;
            this.checkPochylenie.Location = new System.Drawing.Point(6, 100);
            this.checkPochylenie.Name = "checkPochylenie";
            this.checkPochylenie.Size = new System.Drawing.Size(101, 24);
            this.checkPochylenie.TabIndex = 1;
            this.checkPochylenie.Text = "Pochylenie";
            this.checkPochylenie.UseVisualStyleBackColor = true;
            // 
            // checkPogrubienie
            // 
            this.checkPogrubienie.AutoSize = true;
            this.checkPogrubienie.Location = new System.Drawing.Point(6, 45);
            this.checkPogrubienie.Name = "checkPogrubienie";
            this.checkPogrubienie.Size = new System.Drawing.Size(110, 24);
            this.checkPogrubienie.TabIndex = 0;
            this.checkPogrubienie.Text = "Pogrubienie";
            this.checkPogrubienie.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radPomar);
            this.groupBox3.Controls.Add(this.radNiebieski);
            this.groupBox3.Controls.Add(this.radCzerwony);
            this.groupBox3.Location = new System.Drawing.Point(549, 123);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(205, 198);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Kolor czcionki";
            // 
            // radPomar
            // 
            this.radPomar.AutoSize = true;
            this.radPomar.Location = new System.Drawing.Point(6, 155);
            this.radPomar.Name = "radPomar";
            this.radPomar.Size = new System.Drawing.Size(129, 24);
            this.radPomar.TabIndex = 5;
            this.radPomar.TabStop = true;
            this.radPomar.Text = "Pomarańczowy";
            this.radPomar.UseVisualStyleBackColor = true;
            // 
            // radNiebieski
            // 
            this.radNiebieski.AutoSize = true;
            this.radNiebieski.Location = new System.Drawing.Point(6, 99);
            this.radNiebieski.Name = "radNiebieski";
            this.radNiebieski.Size = new System.Drawing.Size(91, 24);
            this.radNiebieski.TabIndex = 4;
            this.radNiebieski.TabStop = true;
            this.radNiebieski.Text = "Niebieski";
            this.radNiebieski.UseVisualStyleBackColor = true;
            // 
            // radCzerwony
            // 
            this.radCzerwony.AutoSize = true;
            this.radCzerwony.Location = new System.Drawing.Point(6, 44);
            this.radCzerwony.Name = "radCzerwony";
            this.radCzerwony.Size = new System.Drawing.Size(94, 24);
            this.radCzerwony.TabIndex = 3;
            this.radCzerwony.TabStop = true;
            this.radCzerwony.Text = "Czerwony";
            this.radCzerwony.UseVisualStyleBackColor = true;
            // 
            // AktualizujBtn
            // 
            this.AktualizujBtn.Location = new System.Drawing.Point(334, 374);
            this.AktualizujBtn.Name = "AktualizujBtn";
            this.AktualizujBtn.Size = new System.Drawing.Size(133, 42);
            this.AktualizujBtn.TabIndex = 5;
            this.AktualizujBtn.Text = "Aktualizuj";
            this.AktualizujBtn.UseVisualStyleBackColor = true;
            this.AktualizujBtn.Click += new System.EventHandler(this.AktualizujBtn_Click);
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(282, 19);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(472, 60);
            this.textBox.TabIndex = 6;
            this.textBox.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.AktualizujBtn);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Tekst";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button AktualizujBtn;
        private System.Windows.Forms.RadioButton radBarDuza;
        private System.Windows.Forms.RadioButton radDuza;
        private System.Windows.Forms.RadioButton radMala;
        private System.Windows.Forms.CheckBox checkPodkresl;
        private System.Windows.Forms.CheckBox checkPochylenie;
        private System.Windows.Forms.CheckBox checkPogrubienie;
        private System.Windows.Forms.RadioButton radPomar;
        private System.Windows.Forms.RadioButton radNiebieski;
        private System.Windows.Forms.RadioButton radCzerwony;
        private System.Windows.Forms.RichTextBox textBox;
    }
}

