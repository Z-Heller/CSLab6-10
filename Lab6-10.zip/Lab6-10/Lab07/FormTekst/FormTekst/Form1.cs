﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormTekst
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void AktualizujBtn_Click(object sender, EventArgs e)
        {
            if (radMala.Checked) textBox.Font = new Font("Segoe UI",10);
            if (radDuza.Checked) textBox.Font = new Font("Segoe UI", 15);
            if (radBarDuza.Checked) textBox.Font = new Font("Segoe UI", 20);

            if (checkPogrubienie.Checked) textBox.Font = new Font(textBox.Font, textBox.Font.Style | FontStyle.Bold);
            if (checkPochylenie.Checked) textBox.Font = new Font(textBox.Font, textBox.Font.Style | FontStyle.Italic);
            if (checkPodkresl.Checked) textBox.Font = new Font(textBox.Font, textBox.Font.Style | FontStyle.Underline);

            if (radCzerwony.Checked) textBox.ForeColor = System.Drawing.Color.Red;
            if (radNiebieski.Checked) textBox.ForeColor = System.Drawing.Color.Blue;
            if (radPomar.Checked) textBox.ForeColor = System.Drawing.Color.Orange;

        }
    }
}
