﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ObliczWage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOblicz_Click(object sender, EventArgs e)
        {
            float wzrost = float.Parse(txtWzrost.Text);

            if (radKobieta.Checked)
            {
                labelWynik.Text = "";
                if (chkStandardowa.Checked)
                {
                    float wagStand = wzrost - 100.0f;
                    labelWynik.Text+=("Waga standardowa: " + wagStand.ToString() + " ");
                }
                if (chkIdealna.Checked)
                {
                    float wagIdeal = (wzrost - 100.0f)*0.85f;
                    labelWynik.Text += ("Waga idealna: " + wagIdeal.ToString() + " ");
                }
            }

            if (radMezczyzna.Checked)
            {
                labelWynik.Text = "";
                if (chkStandardowa.Checked)
                {
                    float wagStand = wzrost - 100.0f;
                    labelWynik.Text += ("Waga standardowa: " + wagStand.ToString() + " ");
                }
                if (chkIdealna.Checked)
                {
                    float wagIdeal = (wzrost - 100.0f) * 0.9f;
                    labelWynik.Text += ("Waga idealna: " + wagIdeal.ToString() + " ");
                }
            }
        }
    }
}
