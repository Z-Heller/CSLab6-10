﻿
namespace ObliczWage
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkIdealna = new System.Windows.Forms.CheckBox();
            this.chkStandardowa = new System.Windows.Forms.CheckBox();
            this.txtWzrost = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radMezczyzna = new System.Windows.Forms.RadioButton();
            this.radKobieta = new System.Windows.Forms.RadioButton();
            this.btnOblicz = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.labelWynik = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(46, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Podaj wzrost";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Podaj płeć:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkIdealna);
            this.groupBox1.Controls.Add(this.chkStandardowa);
            this.groupBox1.Location = new System.Drawing.Point(383, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(253, 83);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Waga:";
            // 
            // chkIdealna
            // 
            this.chkIdealna.AutoSize = true;
            this.chkIdealna.Location = new System.Drawing.Point(7, 53);
            this.chkIdealna.Name = "chkIdealna";
            this.chkIdealna.Size = new System.Drawing.Size(80, 24);
            this.chkIdealna.TabIndex = 1;
            this.chkIdealna.Text = "Idealna";
            this.chkIdealna.UseVisualStyleBackColor = true;
            // 
            // chkStandardowa
            // 
            this.chkStandardowa.AutoSize = true;
            this.chkStandardowa.Location = new System.Drawing.Point(7, 27);
            this.chkStandardowa.Name = "chkStandardowa";
            this.chkStandardowa.Size = new System.Drawing.Size(119, 24);
            this.chkStandardowa.TabIndex = 0;
            this.chkStandardowa.Text = "Standardowa";
            this.chkStandardowa.UseVisualStyleBackColor = true;
            // 
            // txtWzrost
            // 
            this.txtWzrost.Location = new System.Drawing.Point(145, 28);
            this.txtWzrost.Name = "txtWzrost";
            this.txtWzrost.Size = new System.Drawing.Size(203, 27);
            this.txtWzrost.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radMezczyzna);
            this.groupBox2.Controls.Add(this.radKobieta);
            this.groupBox2.Location = new System.Drawing.Point(145, 61);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(203, 50);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            // 
            // radMezczyzna
            // 
            this.radMezczyzna.AutoSize = true;
            this.radMezczyzna.Location = new System.Drawing.Point(101, 15);
            this.radMezczyzna.Name = "radMezczyzna";
            this.radMezczyzna.Size = new System.Drawing.Size(102, 24);
            this.radMezczyzna.TabIndex = 6;
            this.radMezczyzna.Text = "Mężczyzna";
            this.radMezczyzna.UseVisualStyleBackColor = true;
            // 
            // radKobieta
            // 
            this.radKobieta.AutoSize = true;
            this.radKobieta.Checked = true;
            this.radKobieta.Location = new System.Drawing.Point(0, 15);
            this.radKobieta.Name = "radKobieta";
            this.radKobieta.Size = new System.Drawing.Size(82, 24);
            this.radKobieta.TabIndex = 5;
            this.radKobieta.TabStop = true;
            this.radKobieta.Text = "Kobieta";
            this.radKobieta.UseVisualStyleBackColor = true;
            // 
            // btnOblicz
            // 
            this.btnOblicz.Location = new System.Drawing.Point(310, 133);
            this.btnOblicz.Name = "btnOblicz";
            this.btnOblicz.Size = new System.Drawing.Size(94, 29);
            this.btnOblicz.TabIndex = 5;
            this.btnOblicz.Text = "Oblicz";
            this.btnOblicz.UseVisualStyleBackColor = true;
            this.btnOblicz.Click += new System.EventHandler(this.btnOblicz_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(296, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Wynik:";
            // 
            // labelWynik
            // 
            this.labelWynik.AutoSize = true;
            this.labelWynik.Location = new System.Drawing.Point(372, 193);
            this.labelWynik.Name = "labelWynik";
            this.labelWynik.Size = new System.Drawing.Size(0, 20);
            this.labelWynik.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(718, 243);
            this.Controls.Add(this.labelWynik);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnOblicz);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txtWzrost);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Obliczanie wagi";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtWzrost;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkIdealna;
        private System.Windows.Forms.CheckBox chkStandardowa;
        private System.Windows.Forms.RadioButton radMezczyzna;
        private System.Windows.Forms.RadioButton radKobieta;
        private System.Windows.Forms.Button btnOblicz;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelWynik;
    }
}

