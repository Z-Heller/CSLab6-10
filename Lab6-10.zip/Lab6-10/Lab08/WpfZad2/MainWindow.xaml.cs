﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfZad2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Label.Content = "";

            if (CheckBox1.IsChecked == true) Label.Content += "CheckBox1\n";
            if (CheckBox2.IsChecked == true) Label.Content += "CheckBox2\n";

            if (RadioButton1.IsChecked == true) Label.Content += "RadioButton1\n";
            if (RadioButton2.IsChecked == true) Label.Content += "RadioButton2\n";

            if(Lista.SelectedItem == Element_1) Label.Content += "Element 1\n";
            if (Lista.SelectedItem == Element_2) Label.Content += "Element 2\n";
            if (Lista.SelectedItem == Element_3) Label.Content += "Element 3\n";

            Label.Content += TextField.Text;
        }
    }
}
