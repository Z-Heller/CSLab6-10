﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfZad1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SumaBttn_Click(object sender, RoutedEventArgs e)
        {
            float a = float.Parse(textA.Text);
            float b = float.Parse(textB.Text);

            wynikLabel.Content = a.ToString() + " + " + b.ToString() + " = " + (a + b).ToString();
        }

        private void RoznicaBttn_Click(object sender, RoutedEventArgs e)
        {
            float a = float.Parse(textA.Text);
            float b = float.Parse(textB.Text);

            wynikLabel.Content = a.ToString() + " - " + b.ToString() + " = " + (a - b).ToString();
        }

        private void IloczynBttn_Click(object sender, RoutedEventArgs e)
        {
            float a = float.Parse(textA.Text);
            float b = float.Parse(textB.Text);

            wynikLabel.Content = a.ToString() + " * " + b.ToString() + " = " + (a * b).ToString();
        }

        private void IlorazBttn_Click(object sender, RoutedEventArgs e)
        {
            float a = float.Parse(textA.Text);
            float b = float.Parse(textB.Text);

            if (b == 0)
            {
                wynikLabel.Content ="Nie można dzielić przez zero";
                MessageBox.Show("Dzielenie przez zero");
            }
            else wynikLabel.Content = a.ToString() + " / " + b.ToString() + " = " + (a / b).ToString();
        }
    }
}
